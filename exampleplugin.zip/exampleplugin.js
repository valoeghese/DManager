var currentIndex = 0;

subscribeRenameChannel(function(id, name) {
	newName = "off-topic-" + currentIndex.toString();
	currentIndex++;
	return newName;
});